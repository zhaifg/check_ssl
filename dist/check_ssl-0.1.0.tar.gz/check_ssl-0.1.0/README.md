## install 
```bash
pip install check_ssl

```

## usage

```bash
check_ssl https://www.google.com https://www.baidu.com

```

```python

from check_ssl.check import get_certificate

get_certificate("https://www.google.com")

```